/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 0.0, "KoPercent": 100.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "PatternLength_10"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_100"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_20"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_200"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_50"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_1000"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_500"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 35000, 35000, 100.0, 74.33339999999984, 32, 761, 70.0, 118.0, 135.0, 150.0, 255.09274443351188, 94.4142091213877, 114.34332978025581], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["PatternLength_10", 5000, 5000, 100.0, 69.41359999999986, 32, 761, 62.0, 90.0, 104.0, 155.97999999999956, 272.25701061802346, 100.76699904710047, 61.41735298121427], "isController": false}, {"data": ["PatternLength_100", 5000, 5000, 100.0, 75.97219999999997, 33, 244, 72.0, 103.0, 115.0, 141.0, 251.0418235678064, 92.91489368378771, 68.64424863182205], "isController": false}, {"data": ["PatternLength_20", 5000, 5000, 100.0, 68.80159999999987, 32, 258, 64.0, 93.0, 105.0, 138.0, 276.10580374399467, 102.19150353415428, 62.28558658678005], "isController": false}, {"data": ["PatternLength_200", 5000, 5000, 100.0, 66.02020000000022, 34, 149, 63.0, 84.0, 94.0, 113.0, 286.3196472541946, 105.9718225677146, 106.25143159823627], "isController": false}, {"data": ["PatternLength_50", 5000, 5000, 100.0, 70.3995999999999, 34, 209, 64.0, 98.0, 111.0, 140.0, 267.0654844567888, 98.84552598547162, 60.246217685076374], "isController": false}, {"data": ["PatternLength_1000", 5000, 5000, 100.0, 102.38120000000012, 40, 177, 101.0, 141.0, 148.0, 159.98999999999978, 186.84603886397608, 69.15493039985051, 215.31086509715993], "isController": false}, {"data": ["PatternLength_500", 5000, 5000, 100.0, 67.3453999999998, 35, 190, 64.0, 85.0, 93.0, 113.98999999999978, 280.08066323101053, 103.66266734819628, 185.99106542684294], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 35000, 100.0, 100.0], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 35000, 35000, "400/Bad Request", 35000, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["PatternLength_10", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_100", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_20", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_200", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_50", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_1000", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_500", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
