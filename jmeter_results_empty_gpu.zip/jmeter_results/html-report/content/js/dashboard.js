/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 0.0, "KoPercent": 100.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "PatternLength_10"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_100"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_20"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_200"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_50"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_1000"], "isController": false}, {"data": [0.0, 500, 1500, "PatternLength_500"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 35000, 35000, 100.0, 13.547485714285784, 0, 84, 21.0, 36.0, 40.0, 47.0, 1059.7069153445561, 381.5689410310948, 475.0053458429212], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["PatternLength_10", 5000, 5000, 100.0, 2.296399999999996, 0, 38, 2.0, 3.0, 4.0, 6.0, 3852.080123266564, 1425.721061248074, 868.9751059322034], "isController": false}, {"data": ["PatternLength_100", 5000, 5000, 100.0, 16.662399999999998, 2, 48, 16.0, 27.0, 30.0, 36.98999999999978, 895.7362952346829, 331.5273983339305, 244.92789322823361], "isController": false}, {"data": ["PatternLength_20", 5000, 5000, 100.0, 1.9780000000000053, 0, 11, 2.0, 3.0, 4.0, 5.0, 3486.7503486750347, 1290.5062325662484, 786.5618462343097], "isController": false}, {"data": ["PatternLength_200", 5000, 5000, 100.0, 16.690399999999983, 2, 43, 16.0, 28.0, 30.0, 35.0, 901.2256669069934, 333.55910913842825, 334.4392123287671], "isController": false}, {"data": ["PatternLength_50", 5000, 5000, 100.0, 2.7535999999999965, 0, 39, 1.0, 7.0, 12.0, 27.0, 1646.9038208168643, 609.5474102437418, 371.5183423913043], "isController": false}, {"data": ["PatternLength_1000", 5000, 5000, 100.0, 33.25139999999999, 6, 84, 34.0, 43.0, 46.0, 50.0, 532.1413367390378, 169.434217353129, 613.2097435078756], "isController": false}, {"data": ["PatternLength_500", 5000, 5000, 100.0, 21.20020000000011, 3, 61, 21.0, 33.0, 36.0, 41.0, 743.8262421898244, 261.4587013723594, 493.9471139541803], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 28206, 80.58857142857143, 80.58857142857143], "isController": false}, {"data": ["502/Bad Gateway", 6794, 19.411428571428573, 19.411428571428573], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 35000, 35000, "400/Bad Request", 28206, "502/Bad Gateway", 6794, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["PatternLength_10", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_100", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_20", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_200", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_50", 5000, 5000, "400/Bad Request", 5000, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_1000", 5000, 5000, "502/Bad Gateway", 4996, "400/Bad Request", 4, "", "", "", "", "", ""], "isController": false}, {"data": ["PatternLength_500", 5000, 5000, "400/Bad Request", 3202, "502/Bad Gateway", 1798, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
